﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using $rootnamespace$.Base;
using WsiuEditor.Interfaces;
using WsiuEngine.Core;
using WsiuEngine.Core.System;
using WsiuRenderer;

namespace $rootnamespace$
{
    internal partial class $safeitemname$ : ImguiEditorBase
    {
        private const string editorName = "MyImguiEditor";
        internal $safeitemname$(Engine engine, ulong id) : base(engine, id)
        {
            _imguiContext.InitializeWindowClosable(editorName);
            Name = editorName;
        }
        
        public override void Draw()
        {
            // 에디터 그리기 로직을 작성합니다.
        }
    }
}
