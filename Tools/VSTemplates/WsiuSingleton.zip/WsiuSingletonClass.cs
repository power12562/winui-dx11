﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using $rootnamespace$;

namespace $rootnamespace$
{
    internal class $safeitemname$
    {
        private static $safeitemname$ instance = null!;
        internal static void Initialize()
        {
            instance = new();
        }
        
        private $safeitemname$()
        {
        
        }

    }
}
